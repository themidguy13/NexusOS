#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PASS_COUNT=0
FAIL_COUNT=0

pass() {
    echo "  [PASS] $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo "  [FAIL] $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

echo "========================================================"
echo " NEXUS OS // ALL-STAGES (1-6) VERIFICATION SUITE"
echo "========================================================"

# Run Stage 1 verification first
"${PROJECT_DIR}/verify-stage1.sh"

# Check Stage 2-6 executables & configs
stage2_6_files=(
    "airootfs/etc/sddm.conf.d/10-nexus-wayland.conf"
    "airootfs/usr/local/bin/nexus-init-desktop"
    "airootfs/usr/local/bin/nexus-control-center"
    "airootfs/usr/share/applications/nexus-control-center.desktop"
    "airootfs/usr/local/bin/nexus-gamemode"
    "airootfs/etc/skel/.config/MangoHud/MangoHud.conf"
    "airootfs/usr/local/bin/nexus-theme-ctl"
    "airootfs/usr/local/bin/nexus-installer"
    "build-on-windows.bat"
    ".github/workflows/build-nexus-iso.yml"
)

for rel in "${stage2_6_files[@]}"; do
    if [[ -s "${PROJECT_DIR}/${rel}" ]]; then
        pass "Stage 2-6 artifact present: ${rel}"
    else
        fail "Missing Stage 2-6 artifact: ${rel}"
    fi
done

# Validate Bash syntax of all Stage 2-6 shell scripts
for s in "airootfs/usr/local/bin/nexus-init-desktop" \
         "airootfs/usr/local/bin/nexus-gamemode" \
         "airootfs/usr/local/bin/nexus-theme-ctl" \
         "airootfs/usr/local/bin/nexus-installer"; do
    if bash -n "${PROJECT_DIR}/${s}"; then
        pass "Bash syntax valid: ${s}"
    else
        fail "Bash syntax error: ${s}"
    fi
done

# Validate Python AST syntax of NEXUS Control Center
if python3 -m py_compile "${PROJECT_DIR}/airootfs/usr/local/bin/nexus-control-center"; then
    pass "Python bytecode compilation valid: nexus-control-center"
else
    fail "Python syntax error in nexus-control-center"
fi

echo "--------------------------------------------------------"
echo " ALL-STAGES VERIFICATION SUMMARY: ${PASS_COUNT} ADDITIONAL CHECKS PASSED, ${FAIL_COUNT} FAILED"
echo "--------------------------------------------------------"
[[ "${FAIL_COUNT}" -eq 0 ]]
