#!/usr/bin/env bash
# shellcheck disable=SC2034

iso_name="nexus-os"
iso_label="NEXUS_$(date --date="@${SOURCE_DATE_EPOCH:-$(date +%s)}" +%Y%m)"
iso_publisher="NEXUS OS Project <https://nexus-os.local>"
iso_application="NEXUS OS Live/Installation & Gaming Media"
iso_version="1.0.0-zen"
install_dir="nexus"
buildmodes=('iso')
bootmodes=(
  'bios.syslinux.mbr'
  'bios.syslinux.eltorito'
  'uefi-ia32.grub.esp'
  'uefi-x64.grub.esp'
  'uefi-ia32.grub.eltorito'
  'uefi-x64.grub.eltorito'
  'uefi-x64.systemd-boot.esp'
  'uefi-x64.systemd-boot.eltorito'
)
arch="x86_64"
pacman_conf="pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'zstd' '-Xcompression-level' '15' '-b' '1M')
bootstrap_tarball_compression=('zstd' '-c' '-T0' '--auto-threads=logical' '--long' '-19')
file_permissions=(
  ["/etc/shadow"]="0:0:400"
  ["/etc/gshadow"]="0:0:400"
  ["/etc/sudoers.d/00-nexus-wheel"]="0:0:440"
  ["/root"]="0:0:750"
  ["/root/customize_airootfs.sh"]="0:0:755"
  ["/usr/local/bin/nexus-foundation-check"]="0:0:755"
  ["/usr/local/bin/nexus-init-desktop"]="0:0:755"
  ["/usr/local/bin/nexus-control-center"]="0:0:755"
  ["/usr/local/bin/nexus-gamemode"]="0:0:755"
  ["/usr/local/bin/nexus-theme-ctl"]="0:0:755"
  ["/usr/local/bin/nexus-installer"]="0:0:755"
)
