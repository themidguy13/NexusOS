@echo off
setlocal
echo ======================================================================
echo  NEXUS OS // WINDOWS TO BOOTABLE .ISO COMPILER (FOR RUFUS)
echo ======================================================================
echo.
echo NOTE: Rufus requires the compiled .ISO file (generated in the "out"
echo folder by this script), NOT the source code .ZIP archive!
echo.

where docker >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Docker Desktop is not installed or not in your PATH.
    echo.
    echo To compile a real Linux Kernel and Arch ISO on Windows, install
    echo Docker Desktop for Windows ^(https://www.docker.com/products/docker-desktop/^)
    echo OR upload this folder to GitHub to let GitHub Actions compile the .ISO
    echo automatically in the cloud ^(see .github\workflowsuild-nexus-iso.yml^).
    pause
    exit /b 1
)

echo [1/2] Launching privileged Arch Linux build container via Docker...
docker run --rm --privileged -v "%cd%:/workspace" archlinux:latest /bin/bash -c "pacman -Syu --noconfirm archiso git squashfs-tools && cd /workspace && chmod +x build-nexus-iso.sh verify-stage1.sh verify-all-stages.sh airootfs/root/customize_airootfs.sh airootfs/usr/local/bin/* && ./build-nexus-iso.sh"

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ======================================================================
    echo  [SUCCESS] Bootable ISO compiled!
    echo  Open Rufus and select the .iso file inside:
    echo  %cd%\out    echo  ^(When Rufus prompts for ISO vs DD mode, choose DD Image Mode^)
    echo ======================================================================
) else (
    echo.
    echo [ERROR] ISO build failed. Ensure Docker Desktop is running in Linux container mode.
)
pause
