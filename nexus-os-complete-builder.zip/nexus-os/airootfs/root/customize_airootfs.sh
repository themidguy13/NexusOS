#!/usr/bin/env bash
set -euo pipefail

# 1. Generate locales and set timezone
locale-gen
ln -sf /usr/share/zoneinfo/UTC /etc/localtime
hwclock --systohc --utc || true

# 2. Create the default 'nexus' enthusiast user
if ! id -u nexus >/dev/null 2>&1; then
    useradd -m -G wheel,audio,video,input,storage,optical,network,lp,power,docker,libvirt -s /bin/zsh nexus
    echo "nexus:nexus" | chpasswd
fi
echo "root:nexus" | chpasswd

# 3. Initialize NEXUS Desktop layout for default 'nexus' user
su - nexus -c "/usr/local/bin/nexus-init-desktop" || true

# 4. Enable graphical login (SDDM Wayland), Networking, Bluetooth, Docker, Libvirt & IRQ tuning
systemctl enable sddm.service
systemctl enable NetworkManager.service
systemctl enable bluetooth.service
systemctl enable sshd.service
systemctl enable docker.service || true
systemctl enable libvirtd.service || true
systemctl enable irqbalance.service
systemctl enable systemd-timesyncd.service
systemctl enable nvidia-persistenced.service || true

# 5. Rebuild DKMS modules for linux-zen if headers and dkms are present
if command -v dkms >/dev/null 2>&1; then
    KVER="$(ls /usr/lib/modules | grep -E 'zen' | head -n1 || true)"
    if [[ -n "${KVER}" ]]; then
        dkms autoinstall -k "${KVER}" || true
    fi
fi
