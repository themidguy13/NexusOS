#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK_DIR="${PROJECT_DIR}/work"
OUT_DIR="${PROJECT_DIR}/out"

echo "========================================================"
echo " NEXUS OS // FULL ISO BUILD PIPELINE"
echo "========================================================"

# Step 1: Run pre-flight verification first
"${PROJECT_DIR}/verify-all-stages.sh"

# Step 2: Check host privileges and mkarchiso dependency
if [[ "${EUID}" -ne 0 ]]; then
    echo "[ERROR] mkarchiso requires root privileges to mount chroot filesystems."
    echo "        Run: sudo ./build-nexus-iso.sh"
    exit 1
fi

if ! command -v mkarchiso >/dev/null 2>&1; then
    echo "[ERROR] 'mkarchiso' is not installed on this host."
    echo "        On Arch Linux, install it with: sudo pacman -S --needed archiso"
    exit 1
fi

# Step 3: Clean previous build work directory
rm -rf "${WORK_DIR}"
mkdir -p "${WORK_DIR}" "${OUT_DIR}"

# Step 4: Execute mkarchiso
echo "[BUILD] Building NEXUS OS bootable ISO..."
mkarchiso -v -w "${WORK_DIR}" -o "${OUT_DIR}" "${PROJECT_DIR}"

ISO_FILE="$(ls -1t "${OUT_DIR}"/nexus-os-*.iso 2>/dev/null | head -n1 || true)"
if [[ -n "${ISO_FILE}" && -f "${ISO_FILE}" ]]; then
    sha256sum "${ISO_FILE}" > "${ISO_FILE}.sha256"
    echo "========================================================"
    echo " [SUCCESS] Bootable ISO created: ${ISO_FILE}"
    echo " [SHA256]  $(cat "${ISO_FILE}.sha256")"
    echo "========================================================"
else
    echo "[ERROR] ISO build did not produce an output file in ${OUT_DIR}."
    exit 1
fi
