#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PASS_COUNT=0
FAIL_COUNT=0

pass() {
    echo "  [PASS] $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo "  [FAIL] $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

echo "========================================================"
echo " NEXUS OS // STAGE 1 FOUNDATION VERIFICATION SUITE"
echo "========================================================"

required_files=(
    "profiledef.sh"
    "pacman.conf"
    "packages.x86_64"
    "efiboot/loader/loader.conf"
    "efiboot/loader/entries/01-archiso-x86_64-nvidia.conf"
    "efiboot/loader/entries/02-archiso-x86_64-fallback.conf"
    "grub/grub.cfg"
    "syslinux/syslinux.cfg"
    "airootfs/etc/hostname"
    "airootfs/etc/os-release"
    "airootfs/etc/mkinitcpio.conf.d/archiso.conf"
    "airootfs/etc/mkinitcpio.d/linux-zen.preset"
    "airootfs/etc/modprobe.d/nvidia.conf"
    "airootfs/etc/sysctl.d/99-nexus-gaming.conf"
    "airootfs/etc/udev/rules.d/99-nexus-hardware.rules"
    "airootfs/etc/systemd/zram-generator.conf.d/00-nexus-zram.conf"
    "airootfs/etc/sudoers.d/00-nexus-wheel"
    "airootfs/root/customize_airootfs.sh"
    "airootfs/usr/local/bin/nexus-foundation-check"
    "build-nexus-iso.sh"
)

for rel in "${required_files[@]}"; do
    f="${PROJECT_DIR}/${rel}"
    if [[ -s "${f}" ]]; then
        pass "File present & non-empty: ${rel}"
    else
        fail "Missing or empty file: ${rel}"
    fi
done

sh_scripts=(
    "profiledef.sh"
    "airootfs/root/customize_airootfs.sh"
    "airootfs/usr/local/bin/nexus-foundation-check"
    "build-nexus-iso.sh"
    "verify-stage1.sh"
)

for script in "${sh_scripts[@]}"; do
    if bash -n "${PROJECT_DIR}/${script}"; then
        pass "Bash syntax valid (bash -n): ${script}"
    else
        fail "Bash syntax error in: ${script}"
    fi
done

echo "--------------------------------------------------------"
echo " STAGE 1 VERIFICATION SUMMARY: ${PASS_COUNT} PASSED, ${FAIL_COUNT} FAILED"
echo "--------------------------------------------------------"
[[ "${FAIL_COUNT}" -eq 0 ]]
